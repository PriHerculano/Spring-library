package br.com.priscila.library.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import br.com.priscila.library.entities.Book;

public interface BookRepository  extends CrudRepository <Book, String>{
    public List<Book> findByTitleContainingIgnoreCase(String title);
}
