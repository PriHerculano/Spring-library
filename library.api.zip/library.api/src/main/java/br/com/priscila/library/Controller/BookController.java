package br.com.priscila.library.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.priscila.library.entities.Book;
import br.com.priscila.library.repository.BookRepository;

@RestController
@RequestMapping("/api")
public class BookController {
    @Autowired
    private BookRepository repository;

    @PostMapping("/books")
    public Book create(@RequestBody Book entity){
        if(entity.getIsbn() == null || "".equals(entity.getIsbn())){
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "precisa informas o ISBN");
    }

    Optional<Book> existe = repository.findById(entity.getIsbn());
    if (existe.isPresent()){
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Já existe esse ISBN");
    }
    
        Book newEntity = repository.save(entity);
        return newEntity;
    }

    @GetMapping("/books")
    public Iterable<Book> readAll(){
        return repository.findAll();
    }

    @GetMapping("/livros/{isbn}")
    public Book readById(@PathVariable String isbn ){
        Optional<Book> resultado = repository.findById(isbn);

        if(resultado.isPresent()){
            return resultado.get();
        }

        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "ISBN" + isbn + "não encontrado");
    }
}
